# onboarding_app/views.py
from django.shortcuts import render, redirect
from .models import Employee

def employee_list(request):
    employees = Employee.objects.all()
    return render(request, 'onboarding_app/employee_list.html', {'employees': employees})

def employee_detail(request, employee_id):
    employee = Employee.objects.get(id=employee_id)
    return render(request, 'onboarding_app/employee_detail.html', {'employee': employee})

def add_employee(request):
    if request.method == 'POST':
        # Handle form submission and create a new employee
        # Redirect to the employee list
    else:
        return render(request, 'onboarding_app/add_employee.html')

def onboard_employee(request, employee_id):
    employee = Employee.objects.get(id=employee_id)
    employee.is_onboarded = True
    employee.save()
    return redirect('employee_list')


